All data sets contain results of rheological measurements for Dulbecco’s Modified Eagle Medium (DMEM) supplemented with Fetal Bovine Serum (FBS). All measurements performed with Anton Paar MCR 502 rheometer in a cone-plate mode.

Data set legends:

DMEM_and_10pct_FBS: DMEM supplemented with 10% FBS at room temperature
DMEM_and_5pct_FBS: DMEM supplemented with 5% FBS at room temperature
DMEM_and_1pct_FBS: DMEM supplemented with 1% FBS at room temperature
DMEM_and_10pct_FBS_37: DMEM supplemented with 10% FBS at T=37 C

Legends for data included within files.

Originally published/for more information: http://arxiv.org/abs/2409.13650
